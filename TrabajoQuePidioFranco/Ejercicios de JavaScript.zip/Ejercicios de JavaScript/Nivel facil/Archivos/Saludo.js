// El primer ejercicio es este:

// 0) Escribir una funcion para saludar a una persona.
// Requisitos:
//  - La funcion debe recibir un nombre
//  - La funcion debe retornar el saludo de esta forma:

// "Hola, Jorge!"

function saludar() {
  document.getElementById('saludar'); aca.innerText = 'hola Jorge'
}


// function saludar() {
//   document.write("Hola Jorge")
// };
